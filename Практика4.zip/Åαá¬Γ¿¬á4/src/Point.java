public class Point {
     public static int  x=2,y=3;

}