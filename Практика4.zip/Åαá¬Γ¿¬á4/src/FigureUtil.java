public class FigureUtil {
    private FigureUtil(){
    }

    public static int area(Figure figure){
        int sq = figure.area();
        return sq;
    }
    public static float perimeter(Figure figure){
        float pe = figure.perimeter();
        return pe;
    }

    public static void draw(Drawable figure){
        String s1 = figure.draw();
        System.out.println("Черный нарисован " + s1);
        //return s1;
    }

    public static void draw(Drawable figure, Figure.Color color) {
        String s2 = figure.draw(color);
        System.out.println("Нарисован " + s2);
    }
}
