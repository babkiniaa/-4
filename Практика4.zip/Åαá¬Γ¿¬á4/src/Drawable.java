public interface Drawable {
   public String draw();
   public String draw(Figure.Color color);


}
