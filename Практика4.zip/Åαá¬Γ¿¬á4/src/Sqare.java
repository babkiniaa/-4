public class Sqare extends Figure  implements Drawable  {
    public int area(){
        int sq = 20;
        return sq;
    }

    public int perimeter(){
        int pe = 21;
        return pe;
    }

    public String draw(){
        String s1 = (" квадрат c координатами " + Point.x+ " по x и " + Point.y + " по y");
        return s1;
    }

    public String draw(Color color){
        String s2 = " ";
        if (color == Color.Yellow) {
            s2 = " Жёлтый квадрат с кодинатами " + Point.x + " по x и " + Point.y + " По y ";
        }else if (color == Color.Green){
            s2 = " Зеленый квадрат с кодинатами " + Point.x + "  по x и " + Point.y + " По y ";
        }else if (color == Color.Blue){
            s2 = " Голубой квадрат с кодинатами " + Point.x + "  по x и " + Point.y + " По y ";
        }else if (color == Color.Brown){
            s2 = " Коричневый квадрат с кодинатами " + Point.x + " по x и " + Point.y + " По y ";
        }else if (color == Color.White){
            s2 = " Белый квадрат с кодинатами " + Point.x + " по х " + Point.y + " По y ";
        }
        return s2;
    }

}
