public abstract class Figure {
    Point poi;

    public abstract int area();
    public abstract int perimeter();

    public enum Color{
        Yellow,
        Green,
        Blue,
        Brown,
        White
    }

}


